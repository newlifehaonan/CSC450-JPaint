package order;

public interface ITicketOrder {
    void submitTicketOrder();
}
