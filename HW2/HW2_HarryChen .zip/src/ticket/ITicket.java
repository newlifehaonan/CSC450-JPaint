package ticket;

public interface ITicket {
    int getPrice();
    String getSummary();
}
