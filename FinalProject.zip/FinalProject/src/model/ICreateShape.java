package model;

public interface ICreateShape {
}
